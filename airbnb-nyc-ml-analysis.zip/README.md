# 🏙️ Airbnb NYC Business Analysis using Machine Learning

This project analyses Airbnb listing data in New York City to uncover insights using machine learning techniques. The work was completed as part of the Machine Learning module at [University Name], and it demonstrates real-world application of supervised and unsupervised models.

## 📁 Project Structure

- `notebooks/`: Jupyter Notebooks for EDA and ML modelling
- `report/`: Final analytical report (1,000 words)
- `peer-assessment/`: Individual peer reflection
- `portfolio/`: My e-portfolio with key learnings and outcomes
- `data/`: (Dataset file not included – download from Kaggle)
- `results/`: Charts, model results, and outputs

## 🧠 Skills & Tools Used

- Python (pandas, numpy, matplotlib, seaborn, scikit-learn)
- Data cleaning and preprocessing
- EDA and visualisation
- Linear Regression & K-Means Clustering
- Business insights from ML outputs
- Team collaboration and reporting

## 📊 Key Findings

- Price variation is strongly influenced by borough and room type
- Manhattan has the highest price range, but not always the most reviewed
- Cluster analysis identified 3 price-based market segments

## 🔗 Dataset

- [AB_NYC_2019.csv on Kaggle](https://www.kaggle.com/datasets/dgomonov/new-york-city-airbnb-open-data)

## 📌 Author

Abdulrahman Alhashmi – Machine Learning Student, 2025

---

> *This project is part of my academic coursework and e-portfolio submission.*
