# 📚 Machine Learning E-Portfolio – Airbnb NYC Project

**Name:** Abdulrahman Alhashmi  
**Module:** Machine Learning  
**Project Title:** Airbnb Business Analysis Using a Data Science Approach  
**Date:** August 2025

## 1. Project Overview
Analysed Airbnb NYC listings to extract business insights using machine learning methods. Worked collaboratively on data cleaning, EDA, modelling, and reporting.

## 2. Learning Outcomes
- Data cleaning and transformation
- Exploratory data analysis
- Linear regression and clustering
- Model evaluation and interpretation
- Team collaboration and communication

## 3. Tools Used
- Python, Pandas, Scikit-learn, Matplotlib, Seaborn
- Jupyter Notebook, GitHub

## 4. Key Steps
- Removed nulls, handled outliers
- Visualised trends by borough and room type
- Applied regression to predict prices
- Used clustering to segment the market

## 5. Insights
- Room type and borough are major price influencers
- Manhattan listings have highest average prices
- Clusters reveal clear budget, mid-range, and luxury categories

## 6. Reflection
This project helped me understand how to apply machine learning in a real context. I improved my coding, analysis, and teamwork skills, and appreciated the power of visualising and interpreting data effectively.

---

*Full notebook and report can be found in their respective folders.*
